This directory contains a fixed set of novel few-shot examples used to guide LLM generation.
All examples are manually created and do not originate from the evaluation dataset.
The examples are immutable and shared across all experiments.
